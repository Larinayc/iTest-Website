$(document).ready(function(){

//Question set 1

$("#circle1").click(function(){
var i;
var div = $("#circle1");
	for (i = 0; i < 1; i++) {
		div.animate({left: '10%'}, 1500);
    	div.animate({left: '90%'}, 1500);
    }
    div.animate({left: '48%'}, 1500);
    for (i = 0; i < 1; i++) {
		 div.animate({top: '10%'}, 1300);
    	div.animate({top: '90%'}, 1300);
    }
    div.animate({top: '48%'}, 1300);
    $("#circle1").fadeOut(function(){
    	$(".questionboxes").fadeIn();
    	$("#shape").fadeIn();
    	$(".questions1").fadeIn();
    });
});


var count = 0;
$("#answer1").click(function(){
	count += 1;
	alert("You are correct! Your current score is " + count + " !");
    	$(".questions1").fadeOut(function(){
    		$("#circle2").fadeIn();
    	});
    	$(".questionboxes").fadeOut()
    	$("#shape").fadeOut();
    });

$("#answer2").click(function(){
	alert("Oops, that's not correct.");
	$(".questions1").fadeOut(function(){
    		$("#circle2").fadeIn();
    		
    	});
	$(".questionboxes").fadeOut()
	$("#shape").fadeOut()
});

$("#answer3").click(function(){
	alert("Oops, that's not correct.");
	$(".questions1").fadeOut(function(){
    		$("#circle2").fadeIn();
    	});
	$(".questionboxes").fadeOut()
	$("#shape").fadeOut()
});

//Question set 2
$("#circle2").click(function(){
var t = 0;

for (c = 0; c < 100; c++) {function moveit() {
    t += 0.05;

    var r = 300;
    var xcenter = 690;
    var ycenter = 370;
    var newLeft = Math.floor(xcenter + (r * Math.cos(t)));
    var newTop = Math.floor(ycenter + (r * Math.sin(t)));
    $('#circle2').animate({
        top: newTop, 
        left: newLeft,
    }, 1);
}
$(document).ready(function() {
    moveit();
});
}
$("#circle2").fadeOut(function(){
	$("#shape").fadeIn();
	$(".questionboxes").fadeIn();
    	$(".questions2").fadeIn();
    });
});


$("#answer6").click(function(){
	count += 1;
	alert("You are correct! Your current score is " + count + " !");
	$(".questions2").fadeOut(function(){
    		$("#circle3").fadeIn();
    	});
	$(".questionboxes").fadeOut()
	$("#shape").fadeOut()
});

$("#answer5").click(function(){
	alert("Oops, that's not correct.");
$(".questions2").fadeOut(function(){
    		$("#circle3").fadeIn();
    	});
    $(".questionboxes").fadeOut()
    $("#shape").fadeOut()

});

$("#answer4").click(function(){
	alert("Oops, that's not correct.");
	$(".questions2").fadeOut(function(){
    		$("#circle3").fadeIn();
    	});
	$(".questionboxes").fadeOut()
	$("#shape").fadeOut()
});

//Question set 3
  
$("#circle3").click(function(){
$("#circle3").animate({left: '+=21%'}, 700);
var i;
var div = $("#circle3");
	for (i = 0; i < 2; i++) {
		$("#circle3").animate({left: '-=12%', top: '+=30%'}, 700);
		$("#circle3").animate({left: '-=18%'}, 700);	 
		$("#circle3").animate({left: '-=12%', top: '-=30%'}, 700);
		$("#circle3").animate({left: '+=12%', top: '-=30%'}, 700);
		$("#circle3").animate({left: '+=18%'}, 700);
		$("#circle3").animate({left: '+=12%', top: '+=30%'}, 700);
    }
    $("#circle3").fadeOut(function(){
    	$("#shape").fadeIn();
    	$(".questionboxes").fadeIn();
    	$(".questions3").fadeIn();
    });
});

$("#answer8").click(function(){
	count += 1;
	alert("You are correct! Your current score is " + count + " !");
	$("#circle3").fadeOut(function(){
		$(".questionboxes").fadeOut();
    	$(".questions3").fadeOut();
    	$("#shape").fadeOut()
    });
        	document.getElementById("demo").innerHTML = "You scored: " + count + "/3.";

});

$("#answer7").click(function(){
	alert("Oops, that's not correct.");
	$("#circle3").fadeOut(function(){
		$(".questionboxes").fadeOut();
    	$(".questions3").fadeOut();
    	$("#shape").fadeOut()
    });
        	document.getElementById("demo").innerHTML = "You scored: " + count + "/3.";

});

$("#answer9").click(function(){
	alert("Oops, that's not correct.");
	$("#circle3").fadeOut(function(){
		$(".questionboxes").fadeOut();
    	$(".questions3").fadeOut();
    	$("#shape").fadeOut()
    });
        
        	document.getElementById("demo").innerHTML = "You scored: " + count + "/3.";


});


var message = "";
if (count <= 1) {
	message = "Please visit a doctor";
}else if (count == 2){ 
	message = "Potential issue. Might wanna see a doc bro";
}else{
	message = "Awesome! You're prolly fine bro";
}


});
//Larina can you make a program? where if the user scores/count =< 1 then they should visit a doctor, if the count =2 they should probably visit a doctor, and if count = 3 then their vision is fine?