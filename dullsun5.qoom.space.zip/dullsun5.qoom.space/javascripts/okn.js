$(document).ready(function(){
	/* 
	$( "#block1" ).animate({
    top: "10%",}, 2000, function(){
  	$("#block1").hide();
  });
  
  $( "#block2" ).delay(1000).fadeIn(0);
  
  $( "#block2" ).animate({
    top: "10%",
  }, 2000, function(){
  	$("#block2").hide();
  });
  
  $( "#block3" ).delay(2000).fadeIn(0);
  $( "#block3" ).animate({
    top: "10%",
  }, 2000, function(){
  	$("#block3").hide();
  });
  
  $( "#block4" ).delay(3000).fadeIn(0);
  $( "#block4" ).animate({
    top: "10%",
  }, 2000, function(){
  	$("#block4").hide();
  });
  $( "#block5" ).delay(4000).fadeIn(0);
  $( "#block5" ).animate({
    top: "10%",
  }, 2000, function(){
  	$("#block5").hide();
  });
  $( "#block6" ).delay(5000).fadeIn(0);
  $( "#block6" ).animate({
    top: "10%",
  }, 2000, function(){
  	$("#block6").hide();
  });
  $( "#block7" ).delay(6000).fadeIn(0);
  $( "#block7" ).animate({
    top: "10%",
  }, 2000, function(){
  	$("#block7").hide();
  });
  $( "#block8" ).delay(7000).fadeIn(0);
  $( "#block8" ).animate({
    top: "10%",
  }, 2000, function(){
  	$("#block8").hide();
  });
  $( "#block9" ).delay(8000).fadeIn(0);
  $( "#block9" ).animate({
    top: "10%",
  }, 2000, function(){
  	$("#block9").hide();
  });
  */ 
  
  
  /*
  $( "#block1" ).animate({
    top: "10%",}, 2000, function(){
  	$("#block1").hide();
  });
  
  $("#block1").click(function(){
	var i;
	var div = $("#block1");
  */
  
  
  /*
  var i;
  for (i = 0; i < 3; i++) {
    $( "#block1" ).animate({
    top: "10%",}, 2000, function(){
  	$("#block1").hide();
	});
	div.animate({top: '90%'}, 2000);
	$( "#block1" ).delay(1000).fadeIn(0);
  }
*/

/*
$("#block1").click(function(){
 var i;
 var div = $("#block1");
  for (i = 0; i < 3; i++) {
	div.animate({top: '10%'}, 2000);
	div.hide();
	div.animate({top: '90%'}, 2000);
	div.delay(1000).fadeIn(0);
  }
});


function myFunction() {
  var x = document.getElementById("#block1");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
*/
$('#stripes img').animate({
	top: '-=200%'
}, 7000);

});